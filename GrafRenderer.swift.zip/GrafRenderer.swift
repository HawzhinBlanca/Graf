import Foundation
import Metal
import MetalKit
import simd

/// The main renderer for Graf application, handling Metal setup and rendering
public class GrafRenderer: NSObject, MTKViewDelegate {
    // MARK: - Metal Resources
    
    /// The Metal device for GPU operations
    public private(set) var device: MTLDevice?
    
    /// Command queue for submitting work to the GPU
    public private(set) var commandQueue: MTLCommandQueue?
    
    /// The render pipeline state for standard rendering
    public private(set) var pipelineState: MTLRenderPipelineState?
    
    /// The render pipeline state for wireframe rendering
    private var wireframePipelineState: MTLRenderPipelineState?
    
    /// The depth stencil state for proper depth testing
    private var depthState: MTLDepthStencilState?
    
    /// Property for backward compatibility
    public var pipeline: MTLRenderPipelineState? { return pipelineState }
    
    // MARK: - Render Settings
    
    /// Camera for controlling view and projection
    public var camera = Camera()
    
    /// Flag for wireframe rendering mode
    public var wireframe: Bool = true {
        didSet {
            // No need to regenerate geometry when wireframe mode changes
        }
    }
    
    private func updateCurrentVisualization() {
        // Re-generate the current visualization with current settings
        switch currentVisType {
        case .tesseract:
            generateTesseract(scale: currentScale)
        case .hypersphere:
            generateHypersphere(scale: currentScale, resolution: currentResolution)
        case .duocylinder:
            generateDuocylinder(scale: currentScale, resolution: currentResolution)
        case .cliffordTorus:
            generateCliffordTorus(scale: currentScale, resolution: currentResolution)
        default:
            // Default to tesseract for other types
            generateTesseract(scale: currentScale)
        }
    }
    private func visualizationTypeToIndex(_ type: VisualizationType) -> UInt32 {
        switch type {
        case .tesseract: return 0
        case .hypersphere: return 1
        case .duocylinder: return 2
        case .cliffordTorus: return 3
        case .quaternion: return 4
        case .customFunction: return 5
        // Add other cases as needed
        default: return 0
        }
    }

    /// Flag for showing vertex normals
    public var showNormals: Bool = false {
        didSet {
            // Update visualization if normal display changes
            if oldValue != showNormals {
                updateCurrentVisualization()
            }
        }
    }
    private func updateProjectionMatrix() {
        // This method is called when projection type changes
        // For now, we handle projection matrix updates directly in draw()
    }
    
    /// Animation speed multiplier
    public var animationSpeed: Float = 1.0
    
    /// Projection type (perspective, orthographic, stereographic)
    public var projectionType: ProjectionType = .stereographic {
        didSet {
            // Update projection matrix when type changes
            updateProjectionMatrix()
        }
    }
    
    /// Current visualization type
    private var currentVisType: VisualizationType = .tesseract
    
    /// Current scale factor for visualization
    private var currentScale: Float = 1.0
    
    /// Current resolution for visualization
    private var currentResolution: Int = 32
    
    // MARK: - Rotation state for 4D
    private var rotationAngles: (xy: Float, xz: Float, xw: Float, yz: Float, yw: Float, zw: Float) = (0, 0, 0, 0, 0, 0)
    
    // MARK: - Buffers and Geometry
    
    /// Metal vertex buffer
    public private(set) var vertexBuffer: MTLBuffer?
    
    /// Metal index buffer
    public private(set) var indexBuffer: MTLBuffer?
    
    /// Number of indices to draw
    public private(set) var indexCount: Int = 0
    
    /// Storage for 4D vertices
    public private(set) var vertices4D: [Vertex4D] = []
    
    /// Storage for edges (for wireframe rendering)
    private var edges: [(Int, Int)] = []
    
    /// The timestamp for animation
    private var startTime: TimeInterval = Date().timeIntervalSince1970
    
    /// Whether the renderer is initialized
    private var isInitialized: Bool = false
    
    /// 3D vertex for rendering
    public struct Vertex3D {
        var position: SIMD3<Float>
        var normal: SIMD3<Float>
        var color: SIMD4<Float>
        var texCoord: SIMD2<Float>
        
        public init(
            position: SIMD3<Float>,
            normal: SIMD3<Float>,
            color: SIMD4<Float>,
            texCoord: SIMD2<Float>
        ) {
            self.position = position
            self.normal = normal
            self.color = color
            self.texCoord = texCoord
        }
    }
    
    /// Vertex struct for 4D data
    public struct Vertex4D {
        var position: SIMD4<Float>
        var normal: SIMD4<Float>
        var color: SIMD4<Float>
        var texCoord: SIMD2<Float>
        
        public init(
            position: SIMD4<Float>,
            normal: SIMD4<Float> = SIMD4<Float>(0, 0, 0, 1),
            color: SIMD4<Float> = SIMD4<Float>(1, 1, 1, 1),
            texCoord: SIMD2<Float> = SIMD2<Float>(0, 0)
        ) {
            self.position = position
            self.normal = normal
            self.color = color
            self.texCoord = texCoord
        }
    }
    
    /// Uniforms struct that matches the shader expectations
    struct Uniforms {
        var modelMatrix: simd_float4x4
        var viewMatrix: simd_float4x4
        var projectionMatrix: simd_float4x4
        var normalMatrix: simd_float3x3
        var time: Float
        var options: SIMD4<UInt32> // Packed options (wireframe, showNormals, specialEffects, visualizationMode)
    }
    
    // MARK: - Initialization
    
    public override init() {
        super.init()
        
        // Initialize with default settings
        startTime = Date().timeIntervalSince1970
        print("GrafRenderer initialized")
    }
    
    // MARK: - Metal Setup
    
    /// Sets up the Metal rendering environment
    /// - Parameters:
    ///   - device: The Metal device to use
    ///   - view: The MTKView to render into
    public func setupMetal(device: MTLDevice, view: MTKView) {
        print("GrafRenderer.setupMetal called")
        self.device = device
        self.commandQueue = device.makeCommandQueue()
        
        // Set up depth stencil state for proper 3D rendering
        let depthDescriptor = MTLDepthStencilDescriptor()
        depthDescriptor.depthCompareFunction = .less
        depthDescriptor.isDepthWriteEnabled = true
        self.depthState = device.makeDepthStencilState(descriptor: depthDescriptor)
        
        // Set up the rendering pipeline
        setupRenderPipeline(device: device, view: view)
        
        // Create initial visualization
        generateTesseract(scale: 1.0)
        
        isInitialized = true
        print("GrafRenderer.setupMetal completed successfully")
    }
    
    /// Sets up the rendering pipeline with proper shaders and vertex descriptor
    private func setupRenderPipeline(device: MTLDevice, view: MTKView) {
        do {
            // Get default library containing Metal shaders
            guard let library = device.makeDefaultLibrary() else {
                print("ERROR: Failed to load default Metal library")
                return
            }
            
            print("Default Metal library loaded")
            
            // List available shader functions for debugging
            let functions = library.functionNames
            print("Available shader functions: \(functions)")
            
            // Verify shader function names match what's in your Metal file
            guard let vertexFunction = library.makeFunction(name: "vertexShader"),
                  let fragmentFunction = library.makeFunction(name: "fragmentShader") else {
                print("ERROR: Failed to find shader functions")
                return
            }
            
            print("Shader functions loaded")
            
            // Create render pipeline descriptor
            let pipelineDescriptor = MTLRenderPipelineDescriptor()
            pipelineDescriptor.label = "Standard Pipeline"
            pipelineDescriptor.vertexFunction = vertexFunction
            pipelineDescriptor.fragmentFunction = fragmentFunction
            pipelineDescriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
            
            // Configure blending for transparency
            pipelineDescriptor.colorAttachments[0].isBlendingEnabled = true
            pipelineDescriptor.colorAttachments[0].rgbBlendOperation = .add
            pipelineDescriptor.colorAttachments[0].alphaBlendOperation = .add
            pipelineDescriptor.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
            pipelineDescriptor.colorAttachments[0].sourceAlphaBlendFactor = .sourceAlpha
            pipelineDescriptor.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
            pipelineDescriptor.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha
            
            if view.depthStencilPixelFormat != .invalid {
                pipelineDescriptor.depthAttachmentPixelFormat = view.depthStencilPixelFormat
                print("Using depth format: \(view.depthStencilPixelFormat.rawValue)")
            } else {
                print("WARNING: No depth format specified in view")
                // Set a default depth format if not specified
                view.depthStencilPixelFormat = .depth32Float
                pipelineDescriptor.depthAttachmentPixelFormat = .depth32Float
            }
            
            // Configure vertex descriptor to match Vertex3D structure in the shader
            let vertexDescriptor = MTLVertexDescriptor()
            
            // Position attribute (float3)
            vertexDescriptor.attributes[0].format = .float3
            vertexDescriptor.attributes[0].offset = 0
            vertexDescriptor.attributes[0].bufferIndex = 0
            
            // Normal attribute (float3)
            vertexDescriptor.attributes[1].format = .float3
            vertexDescriptor.attributes[1].offset = MemoryLayout<SIMD3<Float>>.stride
            vertexDescriptor.attributes[1].bufferIndex = 0
            
            // Color attribute (float4)
            vertexDescriptor.attributes[2].format = .float4
            vertexDescriptor.attributes[2].offset = MemoryLayout<SIMD3<Float>>.stride * 2
            vertexDescriptor.attributes[2].bufferIndex = 0
            
            // Texture coordinates (float2)
            vertexDescriptor.attributes[3].format = .float2
            vertexDescriptor.attributes[3].offset = MemoryLayout<SIMD3<Float>>.stride * 2 + MemoryLayout<SIMD4<Float>>.stride
            vertexDescriptor.attributes[3].bufferIndex = 0
            
            // Layout configuration
            vertexDescriptor.layouts[0].stride = MemoryLayout<Vertex3D>.stride
            vertexDescriptor.layouts[0].stepRate = 1
            vertexDescriptor.layouts[0].stepFunction = .perVertex
            
            // Assign the vertex descriptor to the pipeline
            pipelineDescriptor.vertexDescriptor = vertexDescriptor
            
            print("Vertex descriptor configured: stride=\(MemoryLayout<Vertex3D>.stride)")
            
            // Create standard pipeline state
            pipelineState = try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
            print("Pipeline state created successfully")
            
        } catch {
            print("ERROR: Failed to create pipeline state: \(error)")
            
            // Get more detailed error information
            if let nsError = error as NSError? {
                for (key, value) in nsError.userInfo {
                    print("  Error detail: \(key): \(value)")
                }
            }
        }
    }
    
    // MARK: - Geometry Generation
    
    /// Generate a tesseract (4D hypercube)
    private func generateTesseract(scale: Float) {
        print("Generating tesseract with scale \(scale)")
        
        // Create all 16 vertices of the tesseract
        var vertices: [SIMD4<Float>] = []
        
        // Generate vertices for a tesseract (4D hypercube)
        for w in [0, 1] {
            for z in [0, 1] {
                for y in [0, 1] {
                    for x in [0, 1] {
                        // Map from 0,1 coordinates to -1,1 range
                        let position = SIMD4<Float>(
                            Float(x) * 2 - 1,
                            Float(y) * 2 - 1,
                            Float(z) * 2 - 1,
                            Float(w) * 2 - 1
                        ) * scale
                        
                        vertices.append(position)
                    }
                }
            }
        }
        
        // Generate edges for the tesseract
        edges = []
        
        // Connect vertices that differ by exactly one bit in their binary representation
        for i in 0..<vertices.count {
            for j in (i+1)..<vertices.count {
                // Count differing coordinates
                var diffCount = 0
                let v1 = vertices[i]
                let v2 = vertices[j]
                
                if abs(v1.x - v2.x) > 0.01 { diffCount += 1 }
                if abs(v1.y - v2.y) > 0.01 { diffCount += 1 }
                if abs(v1.z - v2.z) > 0.01 { diffCount += 1 }
                if abs(v1.w - v2.w) > 0.01 { diffCount += 1 }
                
                // Add edge if exactly one coordinate differs
                if diffCount == 1 {
                    edges.append((i, j))
                }
            }
        }
        
        // Convert to 4D vertices with colors based on position
        vertices4D = vertices.map { position in
            // Normalize position to 0-1 range for color
            let normalizedPos = (position + SIMD4<Float>(1, 1, 1, 1)) * 0.5
            let color = SIMD4<Float>(
                normalizedPos.x,
                normalizedPos.y,
                normalizedPos.z,
                1.0  // Alpha = 1
            )
            
            return Vertex4D(
                position: position,
                normal: normalize(position),  // Use position as normal for basic shading
                color: color,
                texCoord: SIMD2<Float>(0, 0)  // No texturing for now
            )
        }
        
        // Process for rendering (project 4D to 3D)
        updateVertexBuffer()
        
        print("Tesseract generation complete: \(vertices4D.count) vertices, \(edges.count) edges")
    }
    
    /// Update vertex and index buffers from current 4D data
    private func updateVertexBuffer() {
        guard let device = device else {
            print("Cannot update buffers: no Metal device available")
            return
        }
        
        // Project 4D vertices to 3D using the current projection type
        let vertices3D = project4DTo3D()
        
        // Create vertex buffer
        vertexBuffer = device.makeBuffer(
            bytes: vertices3D,
            length: vertices3D.count * MemoryLayout<Vertex3D>.stride,
            options: .storageModeShared
        )
        
        // For line drawing (wireframe)
        var indices: [UInt32] = []
        
        if wireframe {
            // Create edge indices for line rendering
            for (start, end) in edges {
                indices.append(UInt32(start))
                indices.append(UInt32(end))
            }
        } else {
            // For solid rendering, we would need face data
            // This is a placeholder for future implementation
            // For now, just draw each edge as a line
            for (start, end) in edges {
                indices.append(UInt32(start))
                indices.append(UInt32(end))
            }
        }
        
        // Create index buffer
        indexBuffer = device.makeBuffer(
            bytes: indices,
            length: indices.count * MemoryLayout<UInt32>.stride,
            options: .storageModeShared
        )
        
        indexCount = indices.count
        
        print("Buffers updated: \(vertices3D.count) vertices, \(indexCount) indices")
    }
    
    // MARK: - 4D Primitive Generation

    /// Generate a hypersphere in 4D
    private func generateHypersphere(scale: Float, resolution: Int) {
        print("Generating hypersphere with scale \(scale) and resolution \(resolution)")
        
        var vertices: [SIMD4<Float>] = []
        
        // Generate vertices for a 4D hypersphere using parametric equations
        let stepTheta = 2.0 * Float.pi / Float(resolution)
        let stepPhi = Float.pi / Float(resolution)
        let stepPsi = Float.pi / Float(resolution)
        
        for i in 0...resolution {
            let theta = Float(i) * stepTheta
            
            for j in 0...resolution {
                let phi = Float(j) * stepPhi
                
                // Use fewer points in 4th dimension for performance
                for k in 0...(resolution/4) {
                    let psi = Float(k) * stepPsi
                    
                    // 4D spherical coordinates
                    let x = scale * sin(psi) * sin(phi) * cos(theta)
                    let y = scale * sin(psi) * sin(phi) * sin(theta)
                    let z = scale * sin(psi) * cos(phi)
                    let w = scale * cos(psi)
                    
                    vertices.append(SIMD4<Float>(x, y, z, w))
                }
            }
        }
        
        // Generate edges by connecting nearby vertices
        edges = []
        
        // Simple approach: connect vertices if they're within a distance threshold
        let connectionThreshold: Float = scale * 0.3
        
        for i in 0..<vertices.count {
            for j in (i+1)..<vertices.count {
                if simd_distance(vertices[i], vertices[j]) < connectionThreshold {
                    edges.append((i, j))
                    
                    // Limit connections for performance
                    if edges.count >= vertices.count * 3 {
                        break
                    }
                }
            }
        }
        
        // Convert to 4D vertices with colors based on position
        vertices4D = vertices.map { position in
            // Use w coordinate (mapped to 0-1 range) for color
            let w = (position.w / scale + 1.0) * 0.5
            
            let color = SIMD4<Float>(
                w,                 // Red increases with w
                1.0 - w,           // Green decreases with w
                sin(w * 3.14159),  // Blue oscillates with w
                1.0                // Alpha = 1
            )
            
            return Vertex4D(
                position: position,
                normal: normalize(position),  // Use position as normal for basic lighting
                color: color,
                texCoord: SIMD2<Float>(0, 0)
            )
        }
        
        // Update buffers for rendering
        updateVertexBuffer()
        
        print("Hypersphere generation complete: \(vertices4D.count) vertices, \(edges.count) edges")
    }

    /// Generate a Clifford torus in 4D
    private func generateCliffordTorus(scale: Float, resolution: Int) {
        print("Generating Clifford torus with scale \(scale) and resolution \(resolution)")
        
        var vertices: [SIMD4<Float>] = []
        
        // Generate vertices for a Clifford torus
        // A Clifford torus is a product of two circles in 4D
        let majorRadius = scale * 0.7
        let minorRadius = scale * 0.7
        
        let stepU = 2.0 * Float.pi / Float(resolution)
        let stepV = 2.0 * Float.pi / Float(resolution)
        
        for i in 0...resolution {
            let u = Float(i) * stepU
            
            for j in 0...resolution {
                let v = Float(j) * stepV
                
                // Parametric equation of a Clifford torus
                let x = majorRadius * cos(u)
                let y = majorRadius * sin(u)
                let z = minorRadius * cos(v)
                let w = minorRadius * sin(v)
                
                vertices.append(SIMD4<Float>(x, y, z, w))
            }
        }
        
        // Generate edges by connecting adjacent points in the grid
        edges = []
        
        for i in 0..<resolution {
            for j in 0..<resolution {
                let idx = i * (resolution + 1) + j
                
                // Connect to next point in u direction
                edges.append((idx, idx + 1))
                
                // Connect to next point in v direction
                edges.append((idx, idx + (resolution + 1)))
                
                // Connect to next point diagonally
                edges.append((idx, idx + (resolution + 1) + 1))
            }
        }
        
        // Color vertices based on position
        vertices4D = vertices.map { position in
            // Use u and v parameters (recovered from position) for color
            let u = atan2(position.y, position.x)
            let v = atan2(position.w, position.z)
            
            // Map to 0-1 range
            let uNorm = (u + Float.pi) / (2.0 * Float.pi)
            let vNorm = (v + Float.pi) / (2.0 * Float.pi)
            
            let color = SIMD4<Float>(
                uNorm,           // Red from u
                vNorm,           // Green from v
                (uNorm + vNorm) / 2.0,  // Blue is average
                1.0              // Alpha = 1
            )
            
            return Vertex4D(
                position: position,
                normal: normalize(position),  // Approximate normal
                color: color,
                texCoord: SIMD2<Float>(uNorm, vNorm)
            )
        }
        
        // Update buffers for rendering
        updateVertexBuffer()
        
        print("Clifford torus generation complete: \(vertices4D.count) vertices, \(edges.count) edges")
    }

    /// Generate a duocylinder in 4D
    private func generateDuocylinder(scale: Float, resolution: Int) {
        print("Generating duocylinder with scale \(scale) and resolution \(resolution)")
        
        var vertices: [SIMD4<Float>] = []
        
        // Generate vertices for a duocylinder (product of two disks)
        let radius = scale * 0.5
        
        let stepU = 2.0 * Float.pi / Float(resolution)
        let stepR1 = radius / Float(resolution/2)
        let stepR2 = radius / Float(resolution/2)
        
        // Generate the duocylinder as a product of two disks
        for i in 0...resolution {
            let theta1 = Float(i) * stepU
            
            for j in 0...(resolution/2) {
                let r1 = Float(j) * stepR1
                
                for k in 0...resolution {
                    let theta2 = Float(k) * stepU
                    
                    for l in 0...(resolution/2) {
                        let r2 = Float(l) * stepR2
                        
                        // Skip some points for better performance
                        if (j * k * l) % 3 != 0 && j+l > 2 {
                            continue
                        }
                        
                        // Calculate position using disk parametrization
                        let x = r1 * cos(theta1)
                        let y = r1 * sin(theta1)
                        let z = r2 * cos(theta2)
                        let w = r2 * sin(theta2)
                        
                        vertices.append(SIMD4<Float>(x, y, z, w))
                    }
                }
            }
        }
        
        // Generate edges - simple approach connecting nearest neighbors
        edges = []
        let connectionThreshold = scale * 0.2
        
        for i in 0..<vertices.count {
            for j in (i+1)..<min(i+100, vertices.count) {
                if simd_distance(vertices[i], vertices[j]) < connectionThreshold {
                    edges.append((i, j))
                    
                    // Limit connections for performance
                    if edges.count >= vertices.count * 2 {
                        break
                    }
                }
            }
        }
        
        // Color vertices based on position
        vertices4D = vertices.map { position in
            // Calculate disk parameters
            let r1 = sqrt(position.x * position.x + position.y * position.y)
            let r2 = sqrt(position.z * position.z + position.w * position.w)
            
            // Normalize for color
            let r1Norm = r1 / radius
            let r2Norm = r2 / radius
            
            let color = SIMD4<Float>(
                r1Norm,         // Red based on radius in XY plane
                r2Norm,         // Green based on radius in ZW plane
                (r1Norm + r2Norm) / 2.0,  // Blue is average
                1.0              // Alpha = 1
            )
            
            return Vertex4D(
                position: position,
                normal: normalize(SIMD4<Float>(position.x, position.y, position.z, position.w)),
                color: color,
                texCoord: SIMD2<Float>(r1Norm, r2Norm)
            )
        }
        
        // Update buffers for rendering
        updateVertexBuffer()
        
        print("Duocylinder generation complete: \(vertices4D.count) vertices, \(edges.count) edges")
    }

    /// Now update the handleVisualizationUpdate method to call the appropriate generator

    public func handleVisualizationUpdate(typeIndex: Int, resolution: Int, scale: Float) {
        // Store current settings
        currentScale = scale
        currentResolution = resolution
        
        // Convert type index to VisualizationType
        let type: VisualizationType
        switch typeIndex {
        case 0: type = .tesseract
        case 1: type = .hypersphere
        case 2: type = .duocylinder
        case 3: type = .cliffordTorus
        case 4: type = .quaternion
        default: type = .customFunction
        }
        
        currentVisType = type
        
        // Generate appropriate visualization
        switch type {
        case .tesseract:
            generateTesseract(scale: scale)
        case .hypersphere:
            generateHypersphere(scale: scale, resolution: resolution)
        case .duocylinder:
            generateDuocylinder(scale: scale, resolution: resolution)
        case .cliffordTorus:
            generateCliffordTorus(scale: scale, resolution: resolution)
        case .quaternion:
            // Placeholder - implement quaternion visualization
            generateTesseract(scale: scale)  // Default to tesseract for now
        default:
            // Default to tesseract for other types
            generateTesseract(scale: scale)
        }
    }
    
    // Enhance the 4D rotation application to ensure changes are visible

    private func apply4DRotations() -> [Vertex4D] {
        // Apply 4D rotations to the vertices
        let rotated = vertices4D.map { vertex -> Vertex4D in
            var newPosition = vertex.position
            
            // Rotate in XY plane
            if rotationAngles.xy != 0 {
                let c1 = cos(rotationAngles.xy)
                let s1 = sin(rotationAngles.xy)
                let x1 = newPosition.x * c1 - newPosition.y * s1
                let y1 = newPosition.x * s1 + newPosition.y * c1
                newPosition.x = x1
                newPosition.y = y1
            }
            
            // Rotate in XZ plane
            if rotationAngles.xz != 0 {
                let c2 = cos(rotationAngles.xz)
                let s2 = sin(rotationAngles.xz)
                let x2 = newPosition.x * c2 - newPosition.z * s2
                let z2 = newPosition.x * s2 + newPosition.z * c2
                newPosition.x = x2
                newPosition.z = z2
            }
            
            // Rotate in XW plane
            if rotationAngles.xw != 0 {
                let c3 = cos(rotationAngles.xw)
                let s3 = sin(rotationAngles.xw)
                let x3 = newPosition.x * c3 - newPosition.w * s3
                let w3 = newPosition.x * s3 + newPosition.w * c3
                newPosition.x = x3
                newPosition.w = w3
            }
            
            // Rotate in YZ plane
            if rotationAngles.yz != 0 {
                let c4 = cos(rotationAngles.yz)
                let s4 = sin(rotationAngles.yz)
                let y4 = newPosition.y * c4 - newPosition.z * s4
                let z4 = newPosition.y * s4 + newPosition.z * c4
                newPosition.y = y4
                newPosition.z = z4
            }
            
            // Rotate in YW plane
            if rotationAngles.yw != 0 {
                let c5 = cos(rotationAngles.yw)
                let s5 = sin(rotationAngles.yw)
                let y5 = newPosition.y * c5 - newPosition.w * s5
                let w5 = newPosition.y * s5 + newPosition.w * c5
                newPosition.y = y5
                newPosition.w = w5
            }
            
            // Rotate in ZW plane
            if rotationAngles.zw != 0 {
                let c6 = cos(rotationAngles.zw)
                let s6 = sin(rotationAngles.zw)
                let z6 = newPosition.z * c6 - newPosition.w * s6
                let w6 = newPosition.z * s6 + newPosition.w * c6
                newPosition.z = z6
                newPosition.w = w6
            }
            
            var result = vertex
            result.position = newPosition
            return result
        }
        
        return rotated
    }

    // Enhanced projection method for better visibility

    private func project4DTo3D() -> [Vertex3D] {
        // Apply 4D rotations
        let rotatedVertices = apply4DRotations()
        
        // Project to 3D based on the selected projection type
        return rotatedVertices.map { vertex4D in
            let position3D: SIMD3<Float>
            
            switch projectionType {
            case .stereographic:
                // Stereographic projection from 4D to 3D
                // This projects from a point at "infinity" on the w-axis
                // The formula is: p' = p / (1 - p.w*scale)
                let wFactor = 0.4  // Adjust for better visualization
                let denominator = Float(1.0) - vertex4D.position.w * Float(wFactor)
                if denominator.magnitude < Float(0.0001) {                 // Handle division by near-zero
                    position3D = SIMD3<Float>(
                        vertex4D.position.x * 100,
                        vertex4D.position.y * 100,
                        vertex4D.position.z * 100
                    )
                } else {
                    position3D = SIMD3<Float>(
                        vertex4D.position.x / denominator,
                        vertex4D.position.y / denominator,
                        vertex4D.position.z / denominator
                    )
                }
                
            case .perspective:
                // Perspective projection (similar to how 3D perspective works)
                let viewDistance: Float = 2.0  // Distance from 4D camera
                let factor = viewDistance / (viewDistance - vertex4D.position.w)
                position3D = SIMD3<Float>(
                    vertex4D.position.x * factor,
                    vertex4D.position.y * factor,
                    vertex4D.position.z * factor
                )
                
            case .orthographic:
                // Orthographic projection (simply drop the w coordinate)
                position3D = SIMD3<Float>(
                    vertex4D.position.x,
                    vertex4D.position.y,
                    vertex4D.position.z
                )
            }
            
            // Project normal as well
            let normal3D = SIMD3<Float>(
                vertex4D.normal.x,
                vertex4D.normal.y,
                vertex4D.normal.z
            )
            
            return Vertex3D(
                position: position3D,
                normal: normalize(normal3D),  // Ensure normal is normalized
                color: vertex4D.color,
                texCoord: vertex4D.texCoord
            )
        }
    }
    public func draw(in view: MTKView) {
        // Update rotation angles for animation
        let currentTime = Float(Date().timeIntervalSince1970 - startTime)
        
        // Scale animation by speed setting
        rotationAngles.xy = currentTime * 0.3 * animationSpeed
        rotationAngles.xz = currentTime * 0.2 * animationSpeed
        rotationAngles.xw = currentTime * 0.15 * animationSpeed
        rotationAngles.yz = currentTime * 0.1 * animationSpeed
        rotationAngles.yw = currentTime * 0.05 * animationSpeed
        rotationAngles.zw = currentTime * 0.025 * animationSpeed
        
        // Ensure we have all required resources
        guard let device = device,
              let commandQueue = commandQueue,
              let pipelineState = pipelineState,
              let renderPassDescriptor = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable
        else {
            return
        }
        
        // Update vertex buffer with latest 4D projections
        updateVertexBuffer()
        
        // Create command buffer
        guard let commandBuffer = commandQueue.makeCommandBuffer() else {
            print("Failed to create command buffer")
            return
        }
        
        // Create render command encoder
        guard let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor) else {
            print("Failed to create render encoder")
            return
        }
        
        // Set depth state
        if let depthState = depthState {
            renderEncoder.setDepthStencilState(depthState)
        }
        
        // Set the render pipeline state
        renderEncoder.setRenderPipelineState(pipelineState)
        
        // Set vertex buffer
        if let vertexBuffer = vertexBuffer {
            renderEncoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
        } else {
            print("Warning: No vertex buffer available")
            return
        }
        
        
        // Create view & projection matrices
        let viewMatrix = camera.viewMatrix()
        let modelMatrix = matrix_identity_float4x4
        let projectionMatrix = camera.projectionMatrix(type: projectionType)
        
        // Calculate normal matrix (3x3 part of model-view matrix)
        let normalMatrix = simd_float3x3(
            SIMD3<Float>(modelMatrix.columns.0.x, modelMatrix.columns.0.y, modelMatrix.columns.0.z),
            SIMD3<Float>(modelMatrix.columns.1.x, modelMatrix.columns.1.y, modelMatrix.columns.1.z),
            SIMD3<Float>(modelMatrix.columns.2.x, modelMatrix.columns.2.y, modelMatrix.columns.2.z)
        )
        
        // Create uniforms for shaders
        var uniforms = Uniforms(
            modelMatrix: modelMatrix,
            viewMatrix: viewMatrix,
            projectionMatrix: projectionMatrix,
            normalMatrix: normalMatrix,
            time: currentTime,
            options: SIMD4<UInt32>(
                wireframe ? 1 : 0,
                showNormals ? 1 : 0,
                1,  // Enable special effects
                visualizationTypeToIndex(currentVisType)  // Use our helper method
            )
        )
        
        // Set uniforms for vertex and fragment shaders
        renderEncoder.setVertexBytes(
            &uniforms,
            length: MemoryLayout<Uniforms>.stride,
            index: 1
        )
        
        renderEncoder.setFragmentBytes(
            &uniforms,
            length: MemoryLayout<Uniforms>.stride,
            index: 1
        )
        
        // Draw the appropriate geometry
        if let indexBuffer = indexBuffer {
            // Determine the primitive type based on the visualization and wireframe mode
            let primitiveType: MTLPrimitiveType
            
            if wireframe {
                primitiveType = .line
            } else {
                // For non-wireframe, use triangles or points depending on the shape
                switch currentVisType {
                case .hypersphere, .duocylinder:
                    // For point-based visualizations, points may be more appropriate
                    primitiveType = .point
                default:
                    primitiveType = .line  // Default to lines for now
                }
            }
            
            // Draw indexed primitives
            renderEncoder.drawIndexedPrimitives(
                type: primitiveType,
                indexCount: indexCount,
                indexType: .uint32,
                indexBuffer: indexBuffer,
                indexBufferOffset: 0
            )
        } else {
            print("Warning: No index buffer available")
        }
        
        // End encoding and submit
        renderEncoder.endEncoding()
        commandBuffer.present(drawable)
        commandBuffer.commit()
    }
    // MARK: - Public API
    
    /// Get the camera for external manipulation
    public func getCamera() -> Camera {
        return camera
    }
    
    /// Set the projection type
    public func setProjectionType(_ type: ProjectionType) {
        self.projectionType = type
    }
    
    /// Reset the camera to default position
    public func resetCamera() {
        camera = Camera()
    }
    
    // MARK: - Visualization Methods
    
    /// Update visualization data
    public func updateVisualizationData(_ data: VisualizationData) {
        // Convert VisualizationData to internal format
        
        // Extract and store 4D vertices if available
        if !data.originalVertices4D.isEmpty {
            // Create 4D vertices from the data
            self.vertices4D = data.originalVertices4D.map { position ->
                Vertex4D in
                
                // Try to find corresponding index in vertices3D
                let index = data.vertices3D.firstIndex { vertex3D in
                    // Simple proximity check - could be improved
                    let pos3D = SIMD3<Float>(position.x, position.y, position.z)
                    return simd_distance(vertex3D, pos3D) < 0.001
                } ?? 0
                
                // If we have corresponding data, use it
                let normal3D = index < data.normals.count ? data.normals[index] : SIMD3<Float>(0, 0, 1)
                let color = index < data.colors.count ? data.colors[index] : SIMD4<Float>(1, 1, 1, 1)
                
                // Create 4D vertex with corresponding color/normal
                return Vertex4D(
                    position: position,
                    normal: SIMD4<Float>(normal3D.x, normal3D.y, normal3D.z, 0),
                    color: color,
                    texCoord: SIMD2<Float>(0, 0) // No texturing for now
                )
            }
        }
        
        // Store edges if available
        if !data.edges.isEmpty {
            self.edges = data.edges
        }
        
        // Update buffers for rendering
        updateVertexBuffer()
    }
    public func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // Implementation here
    }
    
    /// Handle changes to projection type from UI
    public func handleProjectionTypeChanged(index: Int) {
        let projType: ProjectionType =
            index == 0 ? .stereographic : index == 1 ? .perspective : .orthographic
        setProjectionType(projType)
    }
    
    // MARK: - Camera Control Methods
    
    /// Rotate the camera
    public func rotate(dx: Float, dy: Float) {
        camera.rotateX += dy
        camera.rotateY += dx
    }
    
    /// Pan the camera
    public func pan(dx: Float, dy: Float) {
        camera.panX += dx
        camera.panY += dy
    }
    
    /// Zoom the camera
    public func zoom(factor: Float) {
        camera.zoom *= factor
        camera.zoom = max(0.1, min(camera.zoom, 10.0))  // Clamp zoom
    }
}
